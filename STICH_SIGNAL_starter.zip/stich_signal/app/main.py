from contextlib import asynccontextmanager
from pathlib import Path
import os, sqlite3
from datetime import datetime, timezone
from typing import Literal, Optional
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("STICH_DB_PATH", str(ROOT / "stich_signal.db")))

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@asynccontextmanager
async def lifespan(app: FastAPI):
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS signals (
          id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
          asset TEXT NOT NULL, direction TEXT NOT NULL, expiry_seconds INTEGER NOT NULL,
          status TEXT NOT NULL, entry_price REAL, exit_price REAL, outcome TEXT,
          strategy_version TEXT NOT NULL)""")
    yield

app = FastAPI(title="STICH SIGNAL API", version="0.1.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

class SignalCreate(BaseModel):
    asset: str = Field(min_length=2, max_length=40)
    direction: Literal["CALL", "PUT"]
    expiry_seconds: Literal[5, 10, 15, 60]
    entry_price: Optional[float] = None
    strategy_version: str = "manual-test"

class OutcomeUpdate(BaseModel):
    exit_price: float
    outcome: Literal["WIN", "LOSS", "DRAW"]

@app.get("/", response_class=HTMLResponse)
def index():
    return (ROOT / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/status")
def status():
    return {"app":"STICH SIGNAL", "status":"quote_feed_disconnected", "live_signals_enabled":False,
            "message":"Котирування не підключені. Живі сигнали поки не генеруються."}

@app.get("/api/signals")
def list_signals(limit: int = 50):
    limit = max(1, min(limit, 200))
    with db() as conn:
        rows = conn.execute("SELECT * FROM signals ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/signals", status_code=201)
def create_signal(payload: SignalCreate):
    # Stores explicit test/manual entries only; does not invent market data.
    with db() as conn:
        cur = conn.execute("""INSERT INTO signals
          (created_at, asset, direction, expiry_seconds, status, entry_price, strategy_version)
          VALUES (?, ?, ?, ?, ?, ?, ?)""",
          (datetime.now(timezone.utc).isoformat(), payload.asset, payload.direction,
           payload.expiry_seconds, "PENDING", payload.entry_price, payload.strategy_version))
        sid = cur.lastrowid
    return {"id": sid, "status":"PENDING", "note":"Stored; record outcome only after checking actual data."}

@app.post("/api/signals/{signal_id}/outcome")
def record_outcome(signal_id: int, payload: OutcomeUpdate):
    with db() as conn:
        row = conn.execute("SELECT id,status FROM signals WHERE id=?", (signal_id,)).fetchone()
        if not row: raise HTTPException(status_code=404, detail="Signal not found")
        if row["status"] != "PENDING": raise HTTPException(status_code=409, detail="Outcome already recorded")
        conn.execute("UPDATE signals SET exit_price=?, outcome=?, status='SETTLED' WHERE id=?",
                     (payload.exit_price, payload.outcome, signal_id))
    return {"id":signal_id, "status":"SETTLED", "outcome":payload.outcome}

@app.get("/api/stats")
def stats():
    with db() as conn:
        settled = conn.execute("SELECT COUNT(*) n FROM signals WHERE outcome IS NOT NULL").fetchone()["n"]
        wins = conn.execute("SELECT COUNT(*) n FROM signals WHERE outcome='WIN'").fetchone()["n"]
        losses = conn.execute("SELECT COUNT(*) n FROM signals WHERE outcome='LOSS'").fetchone()["n"]
        draws = conn.execute("SELECT COUNT(*) n FROM signals WHERE outcome='DRAW'").fetchone()["n"]
    return {"settled":settled,"wins":wins,"losses":losses,"draws":draws,
            "win_rate":round(100*wins/(wins+losses),2) if wins+losses else None}
